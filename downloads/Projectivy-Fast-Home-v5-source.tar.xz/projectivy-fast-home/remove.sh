#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./stop.sh
source ./common.sh
"${D[@]}" uninstall uk.onejump2.projectivyfast || true
"${D[@]}" shell rm -rf /data/local/tmp/projectivy-fast-home
echo 'Helper removed. Projectivy and Amazon packages are untouched.'
