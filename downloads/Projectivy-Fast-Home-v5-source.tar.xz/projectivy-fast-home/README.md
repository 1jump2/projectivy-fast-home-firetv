# Projectivy Fast Home for Fire TV (Fire OS 6)

A small, reversible Home-button redirect for older Amazon Fire TV devices. It uses **Projectivy Launcher** for the home screen, a pre-attached black overlay to hide the Amazon Home flash, and an ADB-shell-UID helper to avoid the usual ~5-second app-switch delay.

**Status:** The original v0.5.0 (v5) was confirmed working by a tester on **Fire TV Stick 4K (2018), AFTMM / `mantis`, Fire OS 6.7.1.1** on 24 October 2026. Other models and firmware versions are untested. This repository is a clean copy of that **working v5 baseline**, not the later experimental v5.1 cosmetic change. An always-on Synology NAS recovery task was subsequently verified to restore the redirect after a real Fire TV reboot. The generic `host/ensure-running.sh` and Mac launch agent remain less extensively tested than the original v5 code.

This is **not an independent home-screen app**: [Projectivy Launcher](https://github.com/spocky/miproja1) is a separate dependency. Nothing here roots the device, disables protected Amazon packages, or removes Amazon's advertisements at the operating-system level. It hides Amazon Home during ordinary Home-button navigation.

## How it works

1. `HomeOverlayService` reads Fire OS's Home-button event using the ADB-granted `READ_LOGS` permission.
2. An already-attached `WindowManager` overlay briefly covers Amazon Home in black.
3. An `app_process` daemon started **from ADB as Android's shell user** launches Projectivy via the activity manager over a local-only socket (`127.0.0.1:38276`).
4. The cover clears on Projectivy focus, or automatically after 8.5 seconds as a safety fallback.

The socket accepts only `ping` and a fixed `home` command. It is not exposed to the network.

## Requirements

* The tested Fire TV Stick and firmware above (other Fire OS devices may differ).
* Projectivy Launcher installed, ADB debugging enabled and the development computer authorised by the TV.
* Android SDK, JDK, and ADB on a Mac for building the APK. `build.sh` can discover the developer's external G-DRIVE setup, or use `ANDROID_SDK_ROOT` and `JAVA_HOME`.
* A trusted computer to start the fast shell helper after each TV reboot. Fire OS does not grant ordinary third-party apps shell UID at startup.

## Install

```bash
cp .env.example .env
# Edit .env: FIRETV_DEVICE=your-fire-tv-IP:5555
./setup.sh
```

This builds, signs locally, installs and starts the helper. Generated APKs and local keystores are **not committed**. Existing Projectivy settings remain untouched. For a previously installed v5, **do not reinstall it just to use the host auto-restart**.

Diagnostics:

```bash
./diagnose.sh
```

### After a Fire TV reboot

The shell UID daemon is intentionally *not* started by the Android app: third-party apps cannot assume shell identity after a reboot. The original project's author confirmed this constraint on Fire OS 6 ([upstream notes](https://github.com/pulgagr/tv-vibehack-firetv)).

For an immediate manual restart while your build computer is connected:

```bash
./start.sh
```

### Optional automatic restart from a Mac (not required for Synology)

The host agent restores the **existing** installed v5 shell daemon after the Stick reboots, and starts the Android overlay service if needed. It doesn't rebuild or change the APK. With `.env` set to the Fire Stick's IP:

```bash
./mac/install-autostart.sh
```

The agent checks once per minute while **your Mac is awake and you are signed in**. It can't operate with the Mac asleep, turned off, off the Wi-Fi network, or when Fire TV's ADB debugging is disabled. No direct ADB access from the Internet is required.

To remove just the host auto-restart:

```bash
./mac/uninstall-autostart.sh
```

Agent logs live at `~/Library/Application Support/ProjectivyFastHome/autostart.log`.

### An always-on Linux or Synology NAS

`host/ensure-running.sh` works with Bash and an installed `adb` client. It needs an ADB key authorised once on the TV and a reachable Fire Stick. Use Synology Task Scheduler to invoke it every minute, with `FIRETV_DEVICE` and (optionally) `ADB_BIN` set as environment variables. Configure **Run on the following days: Daily**, **First run: 00:00**, **Every minute**, **Last run: 23:59**. The DSM task must use the same Linux account that authorised ADB. We tested a scheduled recovery after reboot, but you should also run the script manually once before relying on it. For example:

```bash
FIRETV_DEVICE=192.168.1.50:5555 ADB_BIN=/path/to/adb /path/to/repo/host/ensure-running.sh
```

A Synology DSM setup using an authorised `adb` under the scheduled task user was tested successfully with a one-minute daily repetition and an actual Fire TV reboot. The host recovery script is provided as a portable implementation; validate it in your own setup. A running ADB daemon with an authorised key on the NAS is a prerequisite.

## Rollback

To stop the redirect on the TV:

```bash
./stop.sh
```

To remove only this helper from the TV:

```bash
./remove.sh
```

To stop the Mac auto-restart independently use `./mac/uninstall-autostart.sh`. Remove that agent first if you are removing the TV helper. Projectivy and Amazon's launcher are not uninstalled or disabled by these scripts.

## Limitations and safety

* Amazon Home can still appear during startup or certain system screens.
* A firmware update could block `READ_LOGS`, overlays or the shell helper.
* The listener gets access to system logs. Source should be reviewed before sideloading.
* The 8.5-second safety timeout should clear any stuck cover; `stop.sh` is the emergency shutdown.
* Never publish your `.env`, ADB keys, signed APKs with embedded user configuration, device dumps or private keystores.
* This isn't guaranteed compatible with Fire OS 7, Fire OS 8 or Vega OS.

## Attribution and licence

Code for the shell helper was adapted from the MIT-licensed [pulgagr/tv-vibehack-firetv](https://github.com/pulgagr/tv-vibehack-firetv). Its applicable MIT notice is preserved in [`THIRD_PARTY_LICENSE.txt`](THIRD_PARTY_LICENSE.txt). The original code in this repository is MIT-licensed under [`LICENSE`](LICENSE).
