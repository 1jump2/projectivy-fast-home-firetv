#!/usr/bin/env bash
# Run periodically on a trusted always-on Linux/Synology or Mac host with an authorised ADB key.
# Restarts the privileged shell helper and the overlay service after a Fire TV reboot.
# No root access, no Amazon system package changes.
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ -f "$HERE/config" ]]; then
  # Locally written config, not included in the public repository.
  source "$HERE/config"
fi
TV="${FIRETV_DEVICE:-}"
ADB="${ADB_BIN:-adb}"
[[ -n "$TV" ]] || { echo 'FIRETV_DEVICE is required' >&2; exit 2; }
command -v "$ADB" >/dev/null || { echo "adb unavailable: $ADB" >&2; exit 2; }
# Use the dedicated Fire TV ADB key created during the setup, when present.
if [[ -z "${ADB_VENDOR_KEYS:-}" && -f "$HOME/firetv-adb/.android/adbkey" ]]; then
  export ADB_VENDOR_KEYS="$HOME/firetv-adb/.android/adbkey"
fi
# Unreachable means TV is off or booting; the next scheduled run will retry.
"$ADB" connect "$TV" >/dev/null 2>&1 || exit 0
D=("$ADB" -s "$TV")
[[ "$("${D[@]}" get-state 2>/dev/null || true)" == "device" ]] || exit 0
PKG=uk.onejump2.projectivyfast
"${D[@]}" shell pm path "$PKG" 2>/dev/null | grep -q '^package:' || {
  echo 'Projectivy Fast Home APK is not installed. Install the verified v5 first.' >&2
  exit 1
}
REMOTE=/data/local/tmp/projectivy-fast-home/shell-home-start.sh
SHELL_FILE="${SHELL_START_SOURCE:-$HERE/shell-home-start.sh}"
# Check on-device TCP socket. The exact command is tested on Fire OS 6 (mantis).
response="$("${D[@]}" shell 'echo ping | toybox nc -w 2 127.0.0.1 38276' 2>/dev/null | tr -d '\r' || true)"
if [[ "$response" != 'pong 1' ]]; then
  if ! "${D[@]}" shell "test -x '$REMOTE'" >/dev/null 2>&1; then
    [[ -f "$SHELL_FILE" ]] || { echo "Missing shell startup script: $SHELL_FILE" >&2; exit 2; }
    "${D[@]}" shell mkdir -p /data/local/tmp/projectivy-fast-home
    "${D[@]}" push "$SHELL_FILE" "$REMOTE" >/dev/null
    "${D[@]}" shell chmod 755 "$REMOTE"
  fi
  # Shell might initialise after its launcher check, so confirm socket separately.
  "${D[@]}" shell "sh '$REMOTE'" >/dev/null 2>&1 || true
  sleep 2
  response="$("${D[@]}" shell 'echo ping | toybox nc -w 2 127.0.0.1 38276' 2>/dev/null | tr -d '\r' || true)"
  [[ "$response" == 'pong 1' ]] || { echo 'Privileged Home helper not ready; retry next run.' >&2; exit 1; }
  echo 'Shell helper restored.'
fi
# Idempotent: onStartCommand already avoids starting a second log reader.
"${D[@]}" shell am startservice -n "$PKG/.HomeOverlayService" >/dev/null
