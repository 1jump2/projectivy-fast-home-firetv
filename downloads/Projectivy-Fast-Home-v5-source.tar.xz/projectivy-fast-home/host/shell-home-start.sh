#!/system/bin/sh
# This helper runs as the ADB shell user, not a privileged installed app.
# The app can ask it ONLY to show the fixed Projectivy component.
BASE=/data/local/tmp/projectivy-fast-home
PACKAGE=uk.onejump2.projectivyfast
PORT=38276
if [ -f "$BASE/shell.pid" ]; then
  oldpid=$(cat "$BASE/shell.pid")
  if kill -0 "$oldpid" 2>/dev/null; then
    reply=$(echo ping | toybox nc -w 2 127.0.0.1 "$PORT")
    if [ "$reply" = 'pong 1' ]; then
      echo "$reply"
      exit 0
    fi
  fi
fi
path=$(pm path "$PACKAGE")
case "$path" in
  package:*) CLASSPATH=${path#package:} ;;
  *) echo 'APK_NOT_FOUND'; exit 1 ;;
esac
export CLASSPATH
# detaching is needed or adbd closes the process with the interactive session.
setsid nohup app_process /system/bin --nice-name=projfast-shell   uk.onejump2.projectivyfast.ShellHome </dev/null >"$BASE/shell.log" 2>&1 &
echo $! > "$BASE/shell.pid"
sleep 1
reply=$(echo ping | toybox nc -w 2 127.0.0.1 "$PORT")
echo "$reply"
if [ "$reply" != 'pong 1' ]; then
  echo 'SHELL_HELPER_NOT_READY: check /data/local/tmp/projectivy-fast-home/shell.log' >&2
  exit 1
fi
