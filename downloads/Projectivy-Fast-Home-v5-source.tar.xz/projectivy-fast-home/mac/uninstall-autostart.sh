#!/usr/bin/env bash
# Removes only the Mac restart agent; it does not touch apps on the Fire TV.
set -euo pipefail
AGENT="$HOME/Library/LaunchAgents/com.projectivy.fast-home.autostart.plist"
launchctl bootout "gui/$(id -u)/com.projectivy.fast-home.autostart" >/dev/null 2>&1 || true
rm -f "$AGENT"
echo 'Mac auto-restart agent removed. Projectivy and Fire TV apps unchanged.'
