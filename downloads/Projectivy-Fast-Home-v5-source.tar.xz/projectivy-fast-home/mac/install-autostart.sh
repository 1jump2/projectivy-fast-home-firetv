#!/usr/bin/env bash
# Install a macOS LaunchAgent that checks the Fire TV once per minute.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
if [[ -f "$ROOT/.env" ]]; then
  set -a; source "$ROOT/.env"; set +a
fi
TV="${FIRETV_DEVICE:-}"
[[ -n "$TV" ]] || { echo 'Set FIRETV_DEVICE or configure .env first.' >&2; exit 1; }
ADB="$(command -v adb || true)"
[[ -n "$ADB" ]] || { echo 'adb must be installed on this Mac.' >&2; exit 1; }
SUPPORT="$HOME/Library/Application Support/ProjectivyFastHome"
AGENT="$HOME/Library/LaunchAgents/com.projectivy.fast-home.autostart.plist"
mkdir -p "$SUPPORT" "$HOME/Library/LaunchAgents"
cp "$ROOT/host/ensure-running.sh" "$SUPPORT/ensure-running.sh"
cp "$ROOT/shell-home-start.sh" "$SUPPORT/shell-home-start.sh"
chmod 755 "$SUPPORT/ensure-running.sh"
# These local files are outside the GitHub checkout, and contain no ADB private key.
printf 'FIRETV_DEVICE=%q\nADB_BIN=%q\n' "$TV" "$ADB" > "$SUPPORT/config"
# Generate correctly escaped XML even if the macOS account has unusual path characters.
python3 - "$AGENT" "$SUPPORT/ensure-running.sh" "$SUPPORT/autostart.log" <<'PY'
import plistlib,sys
from pathlib import Path
agent,script,log = map(Path,sys.argv[1:])
agent.write_bytes(plistlib.dumps({
    'Label':'com.projectivy.fast-home.autostart',
    'ProgramArguments':['/bin/bash',str(script)],
    'RunAtLoad':True,
    'StartInterval':60,
    'StandardOutPath':str(log),
    'StandardErrorPath':str(log),
},fmt=plistlib.FMT_XML))
PY
JOB="gui/$(id -u)/com.projectivy.fast-home.autostart"
launchctl bootout "$JOB" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$AGENT"
launchctl kickstart "$JOB"
echo 'Mac auto-restart installed. It runs while this Mac is awake and signed in.'
echo "Log: $SUPPORT/autostart.log"
