package uk.onejump2.projectivyfast;

import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Watches the observed Amazon Home system-log event, displays a pre-created
 * WindowManager overlay, then brings the existing Projectivy Activity forward.
 * No accessibility hook and no change to Amazon packages.
 */
public final class HomeOverlayService extends Service {
    private static final String TAG = "FastProjectivy";
    private static final String PROJECTIVY_PKG = "com.spocky.projengmenu";
    private static final String PROJECTIVY_ACTIVITY = "com.spocky.projengmenu.ui.home.MainActivity";
    private static final long SAFETY_MS = 8500L;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private WindowManager wm;
    private FrameLayout cover;
    private Thread reader;
    private volatile boolean running;
    private volatile Process logcat;
    private volatile long lastHome;
    private boolean coverVisible;

    private final Runnable safety = new Runnable() {
        @Override public void run() {
            Log.w(TAG, "SAFETY_TIMEOUT: removing overlay");
            hideCover();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        prepareCover();
    }

    private void prepareCover() {
        try {
            if (!Settings.canDrawOverlays(this)) {
                Log.e(TAG, "NO_OVERLAY_PERMISSION");
                return;
            }
            wm = (WindowManager) getSystemService(WINDOW_SERVICE);
            FrameLayout frame = new FrameLayout(this);
            frame.setBackgroundColor(Color.BLACK);
            TextView message = new TextView(this);
            message.setText("Opening Home");
            message.setGravity(Gravity.CENTER);
            message.setTextColor(Color.LTGRAY);
            message.setTextSize(18f);
            frame.addView(message, new FrameLayout.LayoutParams(-1, -1));
            int type = Build.VERSION.SDK_INT >= 26
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_SYSTEM_ALERT;
            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type, flags, PixelFormat.OPAQUE);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            // Prepare the window once. Switching view visibility does not open an Activity.
            frame.setVisibility(View.GONE);
            wm.addView(frame, params);
            cover = frame;
            Log.i(TAG, "COVER_READY");
        } catch (Exception e) {
            Log.e(TAG, "COVER_PREPARE_FAILED", e);
        }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if ("uk.onejump2.projectivyfast.DEBUG_SHOW".equals(action)) {
            showCover();
            return START_STICKY;
        }
        if ("uk.onejump2.projectivyfast.DEBUG_HIDE".equals(action)) {
            hideCover();
            return START_STICKY;
        }
        if (reader == null || !reader.isAlive()) {
            running = true;
            reader = new Thread(new Runnable() {
                @Override public void run() { watchLogs(); }
            }, "firetv-home-reader");
            reader.setDaemon(true);
            reader.start();
            Log.i(TAG, "HOME_WATCH_STARTED");
        }
        return START_STICKY;
    }

    private void watchLogs() {
        while (running) {
            try {
                // The system Home START event was verified on this exact mantis build.
                Process process = new ProcessBuilder("logcat", "-b", "system", "-b", "events",
                        "-T", "1", "-v", "brief", "ActivityManager:I", "ContextImpl:W",
                        "am_focused_activity:I", "am_resume_activity:I", "*:S")
                        .redirectErrorStream(true).start();
                logcat = process;
                Log.i(TAG, "LOGCAT_READER_STARTED");
                BufferedReader in = new BufferedReader(new InputStreamReader(process.getInputStream()));
                String line;
                while (running && (line = in.readLine()) != null) {
                    handleLogLine(line);
                }
                in.close();
            } catch (Exception e) {
                Log.e(TAG, "LOGCAT_READER_ERROR", e);
            } finally {
                Process p = logcat;
                if (p != null) p.destroy();
                logcat = null;
            }
            if (running) SystemClock.sleep(2500L);
        }
    }

    private void handleLogLine(String line) {
        boolean home = line.contains("handleShortPressOnHome")
                || (line.contains("cat=[android.intent.category.HOME]")
                && line.contains("cmp=com.amazon.tv.launcher/.ui.HomeActivity_vNext"));
        if (home) {
            long now = SystemClock.uptimeMillis();
            if (now - lastHome < 850L) return;
            lastHome = now;
            Log.i(TAG, "HOME_DETECTED");
            main.post(new Runnable() {
                @Override public void run() {
                    showCover();
                    worker.execute(new Runnable() {
                        @Override public void run() { launchProjectivy(); }
                    });
                }
            });
            return;
        }
        // Removing the cover on a focus/resume event avoids the original v4
        // problem: the cover must never remain above the finished launcher.
        boolean resumed = (line.contains("am_focused_activity")
                || line.contains("am_resume_activity"))
                && line.contains(PROJECTIVY_PKG);
        if (resumed) {
            Log.i(TAG, "PROJECTIVY_FOCUSED");
            main.post(new Runnable() {
                @Override public void run() { hideCover(); }
            });
        }
    }

    private void showCover() {
        main.removeCallbacks(safety);
        if (cover == null) {
            Log.e(TAG, "COVER_NOT_READY");
            return;
        }
        cover.setVisibility(View.VISIBLE);
        coverVisible = true;
        Log.i(TAG, "COVER_SHOWN");
        main.postDelayed(safety, SAFETY_MS);
    }

    private void hideCover() {
        main.removeCallbacks(safety);
        if (cover != null && coverVisible) {
            cover.setVisibility(View.GONE);
            coverVisible = false;
            Log.i(TAG, "COVER_HIDDEN");
        }
    }

    private void launchProjectivy() {
        if (tellShellHelper()) {
            Log.i(TAG, "SHELL_LAUNCH_OK");
            return;
        }
        // Fallback: this may be held for around 5 seconds after Home.
        // The overlay masks the wait, then times out if focus logs are missing.
        Log.w(TAG, "SHELL_HELPER_UNAVAILABLE: using normal launch");
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        i.setComponent(new ComponentName(PROJECTIVY_PKG, PROJECTIVY_ACTIVITY));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try { startActivity(i); }
        catch (Exception e) { Log.e(TAG, "LAUNCH_FAILED", e); }
    }

    private boolean tellShellHelper() {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress("127.0.0.1", ShellHome.PORT), 250);
            socket.setSoTimeout(1100);
            socket.getOutputStream().write("home\n".getBytes(StandardCharsets.UTF_8));
            BufferedReader in = new BufferedReader(new InputStreamReader(
                    socket.getInputStream(), StandardCharsets.UTF_8));
            return "ok".equals(in.readLine());
        } catch (Exception e) {
            return false;
        }
    }

    @Override public void onDestroy() {
        running = false;
        Process p = logcat;
        if (p != null) p.destroy();
        main.removeCallbacks(safety);
        hideCover();
        if (cover != null && wm != null) {
            try { wm.removeViewImmediate(cover); }
            catch (Exception e) { Log.e(TAG, "COVER_REMOVE_FAILED", e); }
            cover = null;
        }
        worker.shutdownNow();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
