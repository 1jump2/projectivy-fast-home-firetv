package uk.onejump2.projectivyfast;

import android.content.ComponentName;
import android.content.Intent;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/** Shell-UID fast activity launch. Adapted from the MIT-licensed tv-vibehack-firetv. */
public final class ShellHome {
    static final int PORT = 38276;
    private static Object manager;
    private static Method start;

    public static void main(String[] args) {
        try (ServerSocket server = new ServerSocket(PORT, 4, InetAddress.getByName("127.0.0.1"))) {
            try {
                try { manager = Class.forName("android.app.ActivityManager").getMethod("getService").invoke(null); }
                catch (NoSuchMethodException e) {
                    manager = Class.forName("android.app.ActivityManagerNative").getMethod("getDefault").invoke(null);
                }
                for (Method m : manager.getClass().getMethods()) {
                    if ("startActivity".equals(m.getName()) && m.getParameterTypes().length == 10) {
                        start = m; break;
                    }
                }
                if (start == null) throw new NoSuchMethodException("IActivityManager.startActivity");
            } catch (Exception e) {
                System.err.println("SHELL_INIT_FAILED: " + e);
                return;
            }
            while (true) {
                try (Socket client = server.accept()) {
                    client.setSoTimeout(1500);
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            client.getInputStream(), StandardCharsets.UTF_8));
                    OutputStream output = client.getOutputStream();
                    String command = in.readLine();
                    String response = "";
                    if ("ping".equals(command)) response = "pong 1\n";
                    if ("home".equals(command)) response = openHome() ? "ok\n" : "fail\n";
                    output.write(response.getBytes(StandardCharsets.UTF_8));
                    output.flush();
                } catch (Exception e) {
                    System.err.println("SHELL_CLIENT_FAILED: " + e);
                }
            }
        } catch (Exception e) {
            System.err.println("SHELL_SERVER_FAILED: " + e);
        }
    }

    private static boolean openHome() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setComponent(new ComponentName("com.spocky.projengmenu",
                "com.spocky.projengmenu.ui.home.MainActivity"));
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        try {
            Object result = start.invoke(manager, null, "com.android.shell", intent,
                    null, null, null, 0, 0, null, null);
            return result instanceof Integer && ((Integer) result) >= 0;
        } catch (Exception e) {
            System.err.println("SHELL_LAUNCH_FAILED: " + e);
            return false;
        }
    }
}
