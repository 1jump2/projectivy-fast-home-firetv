#!/usr/bin/env bash
# Build a tiny local APK using the Android SDK already installed on the Mac.
set -euo pipefail
cd "$(dirname "$0")"

find_sdk() {
  for root in "${ANDROID_SDK_ROOT:-}" "${ANDROID_HOME:-}" \
      "/Volumes/THE G DRIVE/Android/sdk" "$HOME/Library/Android/sdk"; do
    if [[ -n "$root" && -d "$root/platforms" && -d "$root/build-tools" ]]; then
      echo "$root"; return 0
    fi
  done
  return 1
}

if ! SDK="$(find_sdk)"; then
  echo "No Android SDK found. Expected on THE G DRIVE/Android/sdk or via ANDROID_SDK_ROOT." >&2
  exit 1
fi

echo "Android SDK: $SDK"
TOOLS=""
for candidate in "$SDK"/build-tools/*; do
  if [[ -x "$candidate/aapt" && -x "$candidate/d8" && -x "$candidate/apksigner" && -x "$candidate/zipalign" ]]; then
    TOOLS="$candidate"
  fi
done
if [[ -z "$TOOLS" ]]; then
  echo "Missing Android SDK build tools: aapt, d8, apksigner and zipalign." >&2
  exit 1
fi
PLATFORM=""
for candidate in "$SDK"/platforms/*; do
  [[ -f "$candidate/android.jar" ]] && PLATFORM="$candidate/android.jar"
done
if [[ -z "$PLATFORM" ]]; then
  echo "No platforms/android-*/android.jar was found in the SDK." >&2; exit 1
fi
# Prefer a JDK already installed on the user's external G-DRIVE.
# This does not modify the Mac's permanent Java settings or ~/.android link.
find_java_home() {
  local root base="/Volumes/THE G DRIVE/Android/java"
  if [[ -n "${JAVA_HOME:-}" && -x "$JAVA_HOME/bin/javac" && -x "$JAVA_HOME/bin/keytool" ]]; then
    printf '%s\n' "$JAVA_HOME"
    return 0
  fi
  # Support a JDK installed directly in java/, a versioned subfolder,
  # or a macOS .jdk bundle containing Contents/Home.
  for root in "$base" "$base"/* "$base"/*/* "$base"/*/*/* \
      "$base"/*/Contents/Home "$base"/*/*/Contents/Home \
      "$base"/*/*/*/Contents/Home; do
    if [[ -x "$root/bin/java" && -x "$root/bin/javac" && -x "$root/bin/keytool" ]]; then
      printf '%s\n' "$root"
      return 0
    fi
  done
  return 1
}

if JDK="$(find_java_home)"; then
  export JAVA_HOME="$JDK"
  export PATH="$JAVA_HOME/bin:$PATH"
  echo "Java JDK: $JAVA_HOME"
else
  for command in java javac keytool; do
    if ! command -v "$command" >/dev/null 2>&1; then
      echo "Missing $command. Could not find a complete JDK under /Volumes/THE G DRIVE/Android/java." >&2
      echo "Please show: ls -la '/Volumes/THE G DRIVE/Android/java'" >&2
      exit 1
    fi
  done
  echo "Java JDK: using existing PATH ($(command -v javac))"
fi

ROOT="$(pwd)"
OUT="$ROOT/out"
rm -rf "$OUT/work"
mkdir -p "$OUT/work/classes" "$OUT/work/dex" "$OUT/work/apk"

echo "Compiling Java..."
find "$ROOT/src" -name '*.java' -print0 | xargs -0 javac -source 8 -target 8 -Xlint:-options \
  -classpath "$PLATFORM" -d "$OUT/work/classes"

echo "Creating DEX..."
find "$OUT/work/classes" -name '*.class' -print0 | xargs -0 "$TOOLS/d8" \
  --min-api 23 --lib "$PLATFORM" --output "$OUT/work/dex"

echo "Packaging APK..."
"$TOOLS/aapt" package -f \
  -M "$ROOT/AndroidManifest.xml" -S "$ROOT/res" -I "$PLATFORM" \
  -F "$OUT/work/apk/unsigned.apk"
(cd "$OUT/work/dex" && "$TOOLS/aapt" add "$OUT/work/apk/unsigned.apk" classes.dex)
"$TOOLS/zipalign" -f 4 "$OUT/work/apk/unsigned.apk" "$OUT/work/apk/aligned.apk"

# Signing material is private to this Mac; never distributed in the ZIP.
KEYDIR="$HOME/.projectivy-fast-home-key"
mkdir -p "$KEYDIR"
chmod 700 "$KEYDIR"
if [[ ! -f "$KEYDIR/signing.keystore" ]]; then
  PASSWORD="$(openssl rand -hex 24)"
  umask 077
  printf '%s\n' "$PASSWORD" > "$KEYDIR/password"
  keytool -genkeypair -noprompt -keystore "$KEYDIR/signing.keystore" \
    -storepass "$PASSWORD" -keypass "$PASSWORD" -alias fasthome \
    -keyalg RSA -keysize 2048 -validity 3650 \
    -dname 'CN=Projectivy Fast Home, O=Local Fire TV, C=GB' >/dev/null
fi
PASSWORD="$(cat "$KEYDIR/password")"
"$TOOLS/apksigner" sign \
  --ks "$KEYDIR/signing.keystore" \
  --ks-key-alias fasthome \
  --ks-pass "pass:$PASSWORD" --key-pass "pass:$PASSWORD" \
  --out "$OUT/Projectivy-Fast-Home.apk" "$OUT/work/apk/aligned.apk"
"$TOOLS/apksigner" verify "$OUT/Projectivy-Fast-Home.apk"
echo "Built and verified: $OUT/Projectivy-Fast-Home.apk"
