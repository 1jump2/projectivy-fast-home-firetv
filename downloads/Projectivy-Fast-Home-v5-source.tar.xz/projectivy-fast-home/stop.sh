#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
"${D[@]}" shell am stopservice -n uk.onejump2.projectivyfast/.HomeOverlayService || true
"${D[@]}" shell 'base=/data/local/tmp/projectivy-fast-home; if [ -f "$base/shell.pid" ]; then p=$(cat "$base/shell.pid"); kill "$p" 2>/dev/null || true; rm -f "$base/shell.pid"; fi'
echo 'Stopped. Amazon Home will work normally. Projectivy remains installed.'
