#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
PKG=uk.onejump2.projectivyfast
if ! "${D[@]}" shell pm path "$PKG" | grep -q '^package:'; then
  echo 'APK not installed. Run ./setup.sh' >&2; exit 1
fi
# READ_LOGS is a development permission: Fire OS 6 accepts ADB pm grant.
echo 'Granting access to the Home-event log and display overlay...'
if ! "${D[@]}" shell pm grant "$PKG" android.permission.READ_LOGS; then
  echo 'READ_LOGS permission rejected. Do not continue with this version.' >&2; exit 1
fi
"${D[@]}" shell appops set "$PKG" SYSTEM_ALERT_WINDOW allow
"${D[@]}" shell appops get "$PKG" SYSTEM_ALERT_WINDOW
# Use the OS shell daemon that can launch an activity without the Home switch lock.
echo 'Starting the fast shell helper...'
"${D[@]}" shell sh /data/local/tmp/projectivy-fast-home/shell-home-start.sh
echo 'Starting the resident overlay/log service...'
"${D[@]}" shell am startservice -n "$PKG/.HomeOverlayService"
echo 'Diagnostics (expect HOME_WATCH_STARTED, COVER_READY and LOGCAT_READER_STARTED):'
sleep 1
"${D[@]}" logcat -d -s FastProjectivy:I '*:S' | tail -n 15
echo 'Open an app and press Home to test. Run ./diagnose.sh after testing.'
