#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
echo 'Overlay app-op:'
"${D[@]}" shell appops get uk.onejump2.projectivyfast SYSTEM_ALERT_WINDOW
echo 'Shell launch helper response:'
"${D[@]}" shell 'echo ping | toybox nc -w 2 127.0.0.1 38276' || true
echo 'Home event and overlay logs:'
"${D[@]}" logcat -d -s FastProjectivy:I FastProjectivy:W FastProjectivy:E '*:S' | tail -n 50
echo 'Shell daemon error log:'
"${D[@]}" shell tail -n 20 /data/local/tmp/projectivy-fast-home/shell.log || true
