#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "${BASH_SOURCE[0]}")"
# Prefer an untracked .env, then the explicit environment variable.
# This avoids committing a user's local IP address to GitHub.
if [[ -f .env ]]; then
  # Shell syntax in .env is intentional; only source your own local file.
  set -a; source ./.env; set +a
fi
DEVICE="${FIRETV_DEVICE:-}"
if [[ -z "$DEVICE" ]]; then
  echo 'Set FIRETV_DEVICE=IP:5555 or copy .env.example to .env and edit it.' >&2
  exit 1
fi
if [[ -f "$HOME/firetv-adb/.android/adbkey" && -z "${ADB_VENDOR_KEYS:-}" ]]; then
  export ADB_VENDOR_KEYS="$HOME/firetv-adb/.android/adbkey"
fi
adb connect "$DEVICE" || true
D=(adb -s "$DEVICE")
if [[ "$("${D[@]}" get-state 2>/dev/null || :)" != "device" ]]; then
  echo "ADB is not connected/authorised for $DEVICE." >&2; exit 1
fi
