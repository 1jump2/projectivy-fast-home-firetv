# Synology NAS reboot recovery

The Fire TV shell-UID helper stops when the Stick reboots. An always-on NAS can restore it automatically over authorised ADB. This technique was verified on a Fire TV Stick 4K (2018), Fire OS 6.7.1.1, with a Synology x86_64 NAS on 24 October 2026.

1. Install the **Linux** Android platform-tools for your NAS architecture. Authorise the NAS with `adb connect FIRETV_IP:5555` and accept the TV's debugging prompt.
2. Copy the project onto the NAS. From SSH under the **same account** the Task Scheduler job will use, run:

   ```bash
   FIRETV_DEVICE=192.168.1.50:5555 ADB_BIN=/path/to/adb /bin/bash /path/to/project/host/ensure-running.sh
   ```

3. In DSM **Control Panel > Task Scheduler > Create > Scheduled Task > User-defined script**, use the authorised account. Under **Schedule** choose **Run on the following days**, **Daily**, **First run 00:00**, **Every minute**, and **Last run 23:59**.
4. In **Task Settings** enter a command with your own network address and paths, for example:

   ```bash
   FIRETV_DEVICE=192.168.1.50:5555 ADB_BIN=/volume1/homes/youruser/firetv-tools/platform-tools/adb /bin/bash /volume1/homes/youruser/projectivy-fast-home/host/ensure-running.sh
   ```

5. Run the task once. Reboot the Fire Stick and verify that Home returns to Projectivy without manually connecting to ADB again. Recovery normally follows within the next minute after the TV comes online.

Never publish your real IP, ADB keys or local `.env` configuration. To disable recovery, disable the task in DSM; this does not uninstall Projectivy.
