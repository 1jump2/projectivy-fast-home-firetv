#!/usr/bin/env bash
source "$(dirname "$0")/common.sh"
MODEL="$("${D[@]}" shell getprop ro.product.device | tr -d '\r')"
if [[ "$MODEL" != "mantis" ]]; then
  echo "Expected Fire TV mantis, got '$MODEL'; aborting." >&2; exit 1
fi
"${D[@]}" shell pm path com.spocky.projengmenu | grep -q '^package:' || {
  echo 'Projectivy missing; aborting.' >&2; exit 1;
}
[[ -f out/Projectivy-Fast-Home.apk ]] || { echo 'Run ./build.sh first.' >&2; exit 1; }
"${D[@]}" install -r out/Projectivy-Fast-Home.apk
"${D[@]}" shell mkdir -p /data/local/tmp/projectivy-fast-home
"${D[@]}" push shell-home-start.sh /data/local/tmp/projectivy-fast-home/shell-home-start.sh >/dev/null
"${D[@]}" shell chmod 755 /data/local/tmp/projectivy-fast-home/shell-home-start.sh
echo 'Installed helper APK and shell helper. No Amazon packages were modified.'
